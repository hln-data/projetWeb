function myFunction() {
  var x = document.getElementById("lediv");
  if (x.innerHTML === " ") {
    x.innerHTML = "helenelin03@gmail.com";
  } else {
    x.innerHTML = " ";
  }
}

