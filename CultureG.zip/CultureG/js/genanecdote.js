var anecdotes = [
    "Le HTML (Hypertext Markup Language) est le langage informatique le plus utilisé pour écrire les pages web.",
    "1 octet est égal à 8 bits.",
    "Le phising est une technique utilisée par les fraudeurs qui consiste à dérober vos informations personnelles (n° de carte de crédit, mots de passe, etc.) en se faisant passer pour votre banque via un courrier électronique ou un site web falsifié."
    "Une adresse IP est un numéro qui identifie chaque matériel informatique (ordinateur, routeur, imprimante) connecté à un réseau informatique."
    "Un shareware est un logiciel dont l’utilisateur doit rétribuer l’auteur s’il veut continuer à l’utiliser après une période de gratuité."
    "Un CPU est un processeur"
]

function nouvelleAnecdote() {
    //action du bouton générer
  var randomNumber = Math.floor(Math.random() * (anecdotes.length));
  document.getElementById('generer').innerHTML = anecdotes[randomNumber];
