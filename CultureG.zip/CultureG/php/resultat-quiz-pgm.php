<!DOCTYPE html>
<html>
    <head>
        <meta charset=UTF-8" />
        <title> Quiz Informatique </title>
        <link rel="stylesheet" type="text/css" href="css/style-quiz.css" />
        <link rel="stylesheet" href = css/styles.css>

    <div class="text-block">
        <div class="header">
            <a href="index.html"/a><img src="img/logo.png" /></a>
            <div class="header-right">
            <ul>
                <a href="index.html">Accueil</a>
                <a href="anecdotes.html">Anecdotes</a>
                <a href="quizz.html" class="active">Quizz</a>
                <a href="contact.html">Contact</a>
            </ul>
        </div>
    </div>
</div>
</head>

<body>
	<div id="page-wrap">
		<h1> Résultats </h1>
        <php
            
            $answer1 = $_POST['question-1-answers'];
            $answer2 = $_POST['question-2-answers'];
            $answer3 = $_POST['question-3-answers'];
            $answer4 = $_POST['question-4-answers'];
            $answer5 = $_POST['question-5-answers'];
        
            totalCorrect = 0;
            if (answer1 == "B") { totalCorrect++; }
            if (answer2 == "C") { totalCorrect++; }
            if (answer3 == "B") { totalCorrect++; }
            if (answer4 == "B") { totalCorrect++; }
            if (answer5 == "A") { totalCorrect++; }
            
            echo <div id='result'> totalCorrect / 5 correct</div>;
            
        >
    </php>
	</div>
</body>
</html>